import React, { useEffect, useState } from 'react';
import axios from 'axios';

function AdminPanel() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/users', {
        headers: { Authorization: token }
      });
      setUsers(res.data);
    };
    fetchUsers();
  }, []);

  return (
    <div>
      <h2>Admin Panel - User List</h2>
      <ul>
        {users.map(user => (
          <li key={user._id}>{user.username} ({user.role})</li>
        ))}
      </ul>
    </div>
  );
}

export default AdminPanel;