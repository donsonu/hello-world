import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Dashboard() {
  const [rates, setRates] = useState([]);

  useEffect(() => {
    const fetchRates = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/rates', {
        headers: { Authorization: token }
      });
      setRates(res.data);
    };
    fetchRates();
  }, []);

  return (
    <div>
      <h2>Binance Rates (USDT)</h2>
      <ul>
        {rates.map(rate => (
          <li key={rate.symbol}>{rate.symbol}: {rate.price}</li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;